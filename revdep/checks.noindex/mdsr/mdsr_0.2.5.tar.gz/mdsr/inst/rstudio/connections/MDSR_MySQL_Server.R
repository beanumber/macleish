db <- mdsr::src_scidb(${0:Schema="airlines"})
